var x = document.getElementById("malek");
var samra = function myFunction(){
    var y = document.getElementById("amine");
    y.classList.add("hide");
}
x.addEventListener("click", samra);
